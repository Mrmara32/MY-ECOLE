/* ============================================================
   CLIENT API — toutes les requêtes vers le backend
============================================================ */
const API_BASE = '/api';
let _token = localStorage.getItem('gs_tok') || null;

async function apiFetch(path, opts = {}) {
  const init = {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(_token ? { Authorization: 'Bearer ' + _token } : {}) },
  };
  if (opts.body !== undefined) init.body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
  const estLecture = init.method === 'GET';

  let res;
  try {
    res = await fetch(API_BASE + path, init);
  } catch (erreurReseau) {
    // fetch() ne lève cette exception qu'en cas d'échec réseau réel (pas de
    // connexion, DNS, etc.) — jamais pour une erreur métier renvoyée par le
    // serveur (celle-ci arrive normalement avec un res.ok=false plus bas).
    if (estLecture) {
      const cache = await offlineLireCache(path);
      if (cache !== undefined) return cache;
      throw new Error('Aucune donnée disponible hors ligne pour cette page. Connectez-vous au moins une fois pour la mettre en cache.');
    }
    const idTemp = offlineIdTemporaire();
    // Génère une clé d'idempotence unique et l'injecte dans le corps AVANT de le
    // mettre en file : elle sera ainsi renvoyée à l'identique à chaque tentative
    // de synchronisation (même si la file est rejouée plusieurs fois), ce qui
    // permet au serveur (@idempotent) de détecter et ignorer un doublon si une
    // première tentative avait en réalité déjà réussi.
    let bodyAvecCle = init.body;
    if (init.method !== 'GET' && bodyAvecCle) {
      try {
        const corpsAnalyse = JSON.parse(bodyAvecCle);
        if (!corpsAnalyse.client_op_id) {
          corpsAnalyse.client_op_id = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : idTemp;
        }
        bodyAvecCle = JSON.stringify(corpsAnalyse);
      } catch (_) { /* corps non-JSON : laissé tel quel, pas de clé d'idempotence possible */ }
    }
    await offlineAjouterFile({ method: init.method, path, body: bodyAvecCle, description: opts.descriptionHorsLigne || path });
    if (opts.miseAJourCacheHorsLigne) {
      try { await opts.miseAJourCacheHorsLigne({ offlineLireCache, offlineSauverCache, idTemp }); }
      catch (e) { console.warn('miseAJourCacheHorsLigne', e); }
    }
    if (typeof offlineMajIndicateur === 'function') offlineMajIndicateur();
    return { id: idTemp, ...(opts.donneesOptimistes || {}), _hors_ligne: true };
  }

  if (res.status === 401) { authLogout(); throw new Error('Session expirée'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok && data.code === 'MOT_DE_PASSE_A_CHANGER' && typeof showPwdModal === 'function') showPwdModal(true);
  if (!res.ok) throw new Error((data.error || `Erreur ${res.status}`) + (data.detail ? '\n\n' + data.detail : ''));
  if (estLecture && typeof offlineSauverCache === 'function') offlineSauverCache(path, data);
  return data;
}

/* Téléchargement d'un fichier protégé (ex : sauvegarde) : la requête doit porter
   le jeton de connexion, d'où ce passage par fetch plutôt qu'un simple lien. */
async function apiTelechargerFichier(path, nomParDefaut) {
  const res = await fetch(API_BASE + path, { headers: _token ? { Authorization: 'Bearer ' + _token } : {} });
  if (res.status === 401) { authLogout(); throw new Error('Session expirée'); }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Erreur ${res.status}`);
  }
  const blob = await res.blob();
  const disposition = res.headers.get('Content-Disposition') || '';
  const trouve = disposition.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
  const nom = trouve ? decodeURIComponent(trouve[1]) : nomParDefaut;
  const url = URL.createObjectURL(blob);
  const lien = document.createElement('a');
  lien.href = url; lien.download = nom;
  document.body.appendChild(lien); lien.click(); lien.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

async function apiUpload(path, formData) {
  const res = await fetch(API_BASE + path, {
    method: 'POST',
    headers: _token ? { Authorization: 'Bearer ' + _token } : {},
    body: formData,
  });
  if (res.status === 401) { authLogout(); throw new Error('Session expirée'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data.error || 'Erreur upload') + (data.detail ? '\n\n' + data.detail : ''));
  return data;
}

/* ── Auth ── */
async function apiLogin(username, password, codeEcole, code2fa) {
  const body = { username, password };
  if (codeEcole) body.code_ecole = codeEcole;
  if (code2fa) body.code_2fa = code2fa;
  const r = await fetch(API_BASE + '/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || 'Erreur');
  return d;
}
const apiMe = () => apiFetch('/auth/me');
function authLogout() {
  // Révoque le jeton côté serveur (sans attendre la réponse : la page se recharge de toute façon).
  if (_token) { try { fetch(API_BASE + '/auth/logout', { method: 'POST', keepalive: true, headers: { Authorization: 'Bearer ' + _token } }); } catch (e) {} }
  _token = null;
  localStorage.removeItem('gs_tok');
  localStorage.removeItem('gs_user');
  location.reload();
}
function apiSetToken(tok) { _token = tok; localStorage.setItem('gs_tok', tok); }

/* ── Settings ── */
const apiGetSettings  = (q='')  => apiFetch('/settings' + (q?'?'+q:''));

/* ── Licence (installation autonome / version .exe uniquement) ── */
const apiGetStatutLicence = () => apiFetch('/licence/statut');
const apiActiverLicence   = (cle) => apiFetch('/licence/activer', { method:'POST', body:{cle} });

/* ── Supervision des écoles clientes (super-administrateur) ── */
const apiGetEcoles     = () => apiFetch('/ecoles');
const apiGetEcole      = (id) => apiFetch(`/ecoles/${id}`);
const apiUpdateEcole   = (id, d) => apiFetch(`/ecoles/${id}`, { method:'PUT', body:d });
const apiConfirmerEcoleManuellement = (id) => apiFetch(`/ecoles/${id}/confirmer-manuellement`, { method:'POST' });
const apiRenvoyerConfirmationEcole  = (id) => apiFetch(`/ecoles/${id}/renvoyer-confirmation`, { method:'POST' });
const apiDeleteEcole   = (id) => apiFetch(`/ecoles/${id}`, { method:'DELETE' });
const apiSaveSettings = (b) => apiFetch('/settings', { method: 'PUT', body: b });

/* ── Users ── */
const apiGetUsers    = ()     => apiFetch('/users');
const apiGetPermissionsModules = () => apiFetch('/permissions/modules');
const apiGetPermissionsUtilisateur = (id) => apiFetch(`/permissions/utilisateur/${id}`);
const apiDefinirPermissions = (id, permissions) => apiFetch(`/permissions/utilisateur/${id}`, { method:'PUT', body:{ permissions } });
const apiCreateUser  = (b)    => apiFetch('/users', { method: 'POST', body: b });
const apiUpdateUser  = (id,b) => apiFetch(`/users/${id}`, { method: 'PUT', body: b });
const apiDeleteUser  = (id)   => apiFetch(`/users/${id}`, { method: 'DELETE' });
const apiResetPwd    = (id,p) => apiFetch(`/users/${id}/reset-password`, { method: 'POST', body: { newPassword: p } });
const api2faStatut   = ()     => apiFetch('/auth/2fa');
const api2faPreparer = ()     => apiFetch('/auth/2fa/preparer', { method: 'POST' });
const api2faActiver  = (code) => apiFetch('/auth/2fa/activer', { method: 'POST', body: { code } });
const api2faDesactiver = (password, code) => apiFetch('/auth/2fa/desactiver', { method: 'POST', body: { password, code } });
const apiRevoquerSessions = (id) => apiFetch(`/users/${id}/revoquer-sessions`, { method: 'POST' });
const apiReset2fa    = (id)   => apiFetch(`/users/${id}/reset-2fa`, { method: 'POST' });
const apiChangePwd   = (o,n)  => apiFetch('/auth/change-password', { method: 'POST', body: { oldPassword: o, newPassword: n } });

/* ── Personnel ── */
const apiGetPersonnel    = ()     => apiFetch('/personnel');
const apiCreatePersonnel = (b)    => apiFetch('/personnel', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouveau personnel — ${b.prenom||''} ${b.nom||''}`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/personnel', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdatePersonnel = (id,b) => apiFetch(`/personnel/${id}`, { method: 'PUT', body: b });
const apiDeletePersonnel = (id)   => apiFetch(`/personnel/${id}`, { method: 'DELETE' });

/* ── Élèves ── */
const apiGetEleves    = (q='')    => apiFetch('/eleves' + (q?'?'+q:''));
const apiGetEleve     = (id)      => apiFetch(`/eleves/${id}`);
const apiCreateEleve  = (b)       => apiFetch('/eleves', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouvel élève — ${b.prenom||''} ${b.nom||''}`,
  donneesOptimistes: { ...b, statut: b.statut || 'actif' },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/eleves', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, statut: b.statut || 'actif', _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateEleve  = (id,b)    => apiFetch(`/eleves/${id}`, { method: 'PUT', body: b });
const apiDeleteEleve  = (id)      => apiFetch(`/eleves/${id}`, { method: 'DELETE' });
const apiUploadPhoto  = (id,fd)   => apiUpload(`/eleves/${id}/photo`, fd);
const apiValiderPreinscription = (id,b) => apiFetch(`/eleves/${id}/valider-preinscription`, { method: 'PUT', body: b });
const apiGetClasses   = ()        => apiFetch('/eleves/meta/classes');

/* ── Notes ── */
const apiGetNotes    = (q='')    => apiFetch('/notes'+(q?'?'+q:''));
const apiCreateNote  = (b)       => apiFetch('/notes', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouvelle note — ${b.matiere||''}`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/notes', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateNote  = (id,b)    => apiFetch(`/notes/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification de note`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/notes', (liste) => Array.isArray(liste) ? liste.map(n => n.id === id ? { ...n, ...b, _hors_ligne: true } : n) : liste);
  },
});
const apiDeleteNote  = (id)      => apiFetch(`/notes/${id}`, { method: 'DELETE' });

/* ── Devoirs ── */
const apiGetDevoirs    = (q='')    => apiFetch('/devoirs'+(q?'?'+q:''));
const apiCreateDevoir  = (b)       => apiFetch('/devoirs', { method: 'POST', body: b });
const apiUpdateDevoir  = (id,b)    => apiFetch(`/devoirs/${id}`, { method: 'PUT', body: b });
const apiDeleteDevoir  = (id)      => apiFetch(`/devoirs/${id}`, { method: 'DELETE' });

/* ── Emploi du temps ── */
const apiGetEdt    = (q='')    => apiFetch('/emploi-du-temps'+(q?'?'+q:''));
const apiCreateEdt = (b)       => apiFetch('/emploi-du-temps', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouveau créneau d'emploi du temps`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/emploi-du-temps', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateEdt = (id,b)    => apiFetch(`/emploi-du-temps/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification d'un créneau d'emploi du temps`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/emploi-du-temps', (liste) => Array.isArray(liste) ? liste.map(c => c.id === id ? { ...c, ...b, _hors_ligne: true } : c) : liste);
  },
});
const apiDeleteEdt = (id)      => apiFetch(`/emploi-du-temps/${id}`, { method: 'DELETE' });

/* ── Absences ── */
const apiGetAbsences    = (q='')    => apiFetch('/absences'+(q?'?'+q:''));
const apiPointageJour = (q='') => apiFetch('/pointage/jour'+(q?'?'+q:''));
const apiPointageMensuel = (q='') => apiFetch('/pointage/mensuel'+(q?'?'+q:''));
const apiPointagePassages = (q='') => apiFetch('/pointage/passages'+(q?'?'+q:''));
const apiPointageAppareils = () => apiFetch('/pointage/appareils');
const apiPointageCreerAppareil = b => apiFetch('/pointage/appareils', { method: 'POST', body: b });
const apiPointageModifierAppareil = (id, b) => apiFetch(`/pointage/appareils/${id}`, { method: 'PUT', body: b });
const apiPointageSupprimerAppareil = id => apiFetch(`/pointage/appareils/${id}`, { method: 'DELETE' });
const apiPointagePersonnes = q => apiFetch('/pointage/personnes?' + q);
const apiPointageDefinirCode = b => apiFetch('/pointage/codes', { method: 'PUT', body: b });
const apiPointageCodesAuto = type => apiFetch('/pointage/codes/auto', { method: 'POST', body: { type } });
const apiPointageBadges = (type, classe) => apiFetch('/pointage/badges?type=' + type + (classe ? '&classe=' + encodeURIComponent(classe) : ''));
const apiPointageScan = contenu => apiFetch('/pointage/scan', { method: 'POST', body: { contenu } });
let _waAutoActif = null;
const whatsappAutoActif = async () => {
  if (_waAutoActif === null) { try { _waAutoActif = !!(await apiFetch('/whatsapp/statut')).actif; } catch (e) { _waAutoActif = false; } }
  return _waAutoActif;
};
const apiWhatsappAbsence = id => apiFetch('/whatsapp/absence/' + encodeURIComponent(id), { method: 'POST' });
const apiWhatsappRelance = id => apiFetch('/whatsapp/relance/' + encodeURIComponent(id), { method: 'POST' });
let _smsAutoActif = null;
const smsAutoActif = async () => {
  if (_smsAutoActif === null) { try { _smsAutoActif = !!(await apiFetch('/sms/statut')).actif; } catch (e) { _smsAutoActif = false; } }
  return _smsAutoActif;
};
const apiSmsAbsence = (id, message) => apiFetch('/sms/absence/' + encodeURIComponent(id), { method: 'POST', body: { message } });
const apiSmsRelance = (id, message) => apiFetch('/sms/relance/' + encodeURIComponent(id), { method: 'POST', body: { message } });
let _omActif = null;
const orangeMoneyActif = async () => {
  if (_omActif === null) { try { _omActif = !!(await apiFetch('/orange-money/statut')).actif; } catch (e) { _omActif = false; } }
  return _omActif;
};
const apiOrangeMoneyLien = (eleve_id, montant) => apiFetch('/orange-money/lien', { method: 'POST', body: { eleve_id, montant } });
const apiPointageParametres = () => apiFetch('/pointage/parametres');
const apiPointageSauverParametres = b => apiFetch('/pointage/parametres', { method: 'PUT', body: b });
const apiPointageManuel = b => apiFetch('/pointage/manuel', { method: 'POST', body: b });
const apiPointageCloture = b => apiFetch('/pointage/cloture', { method: 'POST', body: b });
const apiPrevenirParentAbsence = (id, canal) => apiFetch(`/absences/${id}/prevenir`, { method: 'POST', body: { canal } });
const apiCreateAbsence  = (b)       => apiFetch('/absences', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Absence/retard — ${b.date_abs || ''}`,
  donneesOptimistes: { ...b, statut: 'a_synchroniser' },
  miseAJourCacheHorsLigne: async ({ offlineLireCache, idTemp }) => {
    await offlinePatcherVariantes('/absences', (liste) => {
      if (!Array.isArray(liste)) return liste;
      return [{ ...b, id: idTemp, _hors_ligne: true }, ...liste];
    });
  },
});
const apiUpdateAbsence  = (id,b)    => apiFetch(`/absences/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification d'une absence`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/absences', (liste) => Array.isArray(liste) ? liste.map(a => a.id === id ? { ...a, ...b, _hors_ligne: true } : a) : liste);
  },
});
const apiDeleteAbsence  = (id)      => apiFetch(`/absences/${id}`, { method: 'DELETE' });
const apiStatsAbsences  = (id)      => apiFetch(`/absences/stats/${id}`);

/* ── Absences du personnel (point 6) ── */
const apiGetAbsencesPersonnel       = (q='') => apiFetch('/absences-personnel'+(q?'?'+q:''));
const apiGetAbsencesPersonnelAujourdhui = () => apiFetch('/absences-personnel/aujourd-hui');
const apiSignalerAbsencePersonnel   = (b)    => apiFetch('/absences-personnel', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Absence de personnel signalée`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/absences-personnel', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateAbsencePersonnel     = (id,b) => apiFetch(`/absences-personnel/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification d'une absence de personnel`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/absences-personnel', (liste) => Array.isArray(liste) ? liste.map(a => a.id === id ? { ...a, ...b, _hors_ligne: true } : a) : liste);
  },
});
const apiDeleteAbsencePersonnel     = (id)   => apiFetch(`/absences-personnel/${id}`, { method: 'DELETE' });

/* ── Réinscriptions ── */
const apiGetReinscriptions   = (q='')    => apiFetch('/reinscriptions'+(q?'?'+q:''));
const apiCreateReinscription = (b)       => apiFetch('/reinscriptions', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouvelle demande de réinscription`,
  donneesOptimistes: { ...b, statut: 'en_attente' },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/reinscriptions', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, statut: 'en_attente', _hors_ligne: true }, ...liste] : liste);
  },
});
const apiValiderReinscription= (id,b)    => apiFetch(`/reinscriptions/${id}/valider`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Validation de réinscription`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    // Remarque : en ligne, valider une réinscription génère aussi automatiquement le
    // paiement des frais de réinscription (voir routes/scolarite_routes.py). Cet effet
    // de bord serveur ne peut pas être simulé hors ligne — il aura bien lieu, mais
    // seulement une fois la synchronisation réellement effectuée.
    await offlinePatcherVariantes('/reinscriptions', (liste) => Array.isArray(liste) ? liste.map(r => r.id === id ? { ...r, statut: b.statut || 'validee', _hors_ligne: true } : r) : liste);
  },
});
const apiDeleteReinscription = (id)      => apiFetch(`/reinscriptions/${id}`, { method: 'DELETE' });

/* ── Transactions ── */
const apiGetTransactions    = (q='')    => apiFetch('/transactions'+(q?'?'+q:''));

/* ── Fournisseurs ── */
const apiGetFournisseurs    = (q='')    => apiFetch('/fournisseurs'+(q?'?'+q:''));
const apiGetFournisseur     = (id)      => apiFetch(`/fournisseurs/${id}`);
const apiCreateFournisseur  = (d)       => apiFetch('/fournisseurs', {
  method:'POST', body:d,
  descriptionHorsLigne: `Nouveau fournisseur — ${d.nom||''}`,
  donneesOptimistes: { ...d },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/fournisseurs', (liste) => Array.isArray(liste) ? [{ ...d, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateFournisseur  = (id,d)    => apiFetch(`/fournisseurs/${id}`, {
  method:'PUT', body:d,
  descriptionHorsLigne: `Modification de fournisseur`,
  donneesOptimistes: { id, ...d },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/fournisseurs', (liste) => Array.isArray(liste) ? liste.map(f => f.id === id ? { ...f, ...d, _hors_ligne: true } : f) : liste);
  },
});
const apiDeleteFournisseur  = (id)      => apiFetch(`/fournisseurs/${id}`, { method:'DELETE' });

// ── Logistique : Stock / Fournitures ──
const apiGetStockProduits   = (q='')    => apiFetch('/stock/produits'+(q?'?'+q:''));
const apiCreateStockProduit = (d)       => apiFetch('/stock/produits', { method:'POST', body:d });
const apiUpdateStockProduit = (id,d)    => apiFetch(`/stock/produits/${id}`, { method:'PUT', body:d });
const apiDeleteStockProduit = (id)      => apiFetch(`/stock/produits/${id}`, { method:'DELETE' });
const apiGetStockMouvements = (q='')    => apiFetch('/stock/mouvements'+(q?'?'+q:''));
const apiCreateStockMouvement = (d)     => apiFetch('/stock/mouvements', {
  method:'POST', body:d,
  descriptionHorsLigne: `Mouvement de stock (${d.type==='sortie'?'sortie':'entrée'})`,
  donneesOptimistes: { id: d.produit_id },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/stock/produits', (liste) => {
      if (!Array.isArray(liste)) return liste;
      const delta = (d.type === 'entree' ? 1 : -1) * (parseFloat(d.quantite)||0);
      return liste.map(p => p.id === d.produit_id ? { ...p, quantite: (p.quantite||0) + delta, _hors_ligne: true } : p);
    });
  },
});

// ── Logistique : Achats / Commandes ──
const apiGetCommandes       = (q='')    => apiFetch('/commandes'+(q?'?'+q:''));
const apiGetCommande        = (id)      => apiFetch(`/commandes/${id}`);
const apiCreateCommande     = (d)       => apiFetch('/commandes', {
  method:'POST', body:d,
  descriptionHorsLigne: `Nouveau bon de commande`,
  donneesOptimistes: { ...d, statut: d.statut || 'brouillon' },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/commandes', (liste) => Array.isArray(liste) ? [{ ...d, id: idTemp, statut: d.statut || 'brouillon', nb_lignes: (d.lignes||[]).length, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateCommande     = (id,d)    => apiFetch(`/commandes/${id}`, {
  method:'PUT', body:d,
  descriptionHorsLigne: `Modification d'un bon de commande`,
  donneesOptimistes: { id, ...d },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/commandes', (liste) => Array.isArray(liste) ? liste.map(c => c.id === id ? { ...c, ...d, _hors_ligne: true } : c) : liste);
  },
});
const apiReceptionnerCommande = (id)    => apiFetch(`/commandes/${id}/receptionner`, {
  method:'POST',
  descriptionHorsLigne: `Réception d'un bon de commande`,
  donneesOptimistes: { id },
  miseAJourCacheHorsLigne: async () => {
    // Remarque : la réception réelle incrémente aussi le stock des produits liés
    // (voir routes/logistique_routes.py). Cet effet n'est PAS simulé ici pour éviter
    // toute désynchronisation entre le statut affiché et les quantités en stock —
    // le stock ne bougera réellement qu'au moment de la synchronisation effective.
    await offlinePatcherVariantes('/commandes', (liste) => Array.isArray(liste) ? liste.map(c => c.id === id ? { ...c, statut: 'recue', _hors_ligne: true } : c) : liste);
  },
});
const apiDeleteCommande     = (id)      => apiFetch(`/commandes/${id}`, { method:'DELETE' });

// ── Logistique : Maintenance ──
const apiGetMaintenance     = (q='')    => apiFetch('/maintenance'+(q?'?'+q:''));
const apiCreateMaintenance  = (d)       => apiFetch('/maintenance', {
  method:'POST', body:d,
  descriptionHorsLigne: `Signalement — ${d.titre||''}`,
  donneesOptimistes: { ...d, statut: 'signalee' },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/maintenance', (liste) => Array.isArray(liste) ? [{ ...d, id: idTemp, statut: 'signalee', _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateMaintenance  = (id,d)    => apiFetch(`/maintenance/${id}`, {
  method:'PUT', body:d,
  descriptionHorsLigne: `Modification d'une intervention`,
  donneesOptimistes: { id, ...d },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/maintenance', (liste) => Array.isArray(liste) ? liste.map(m => m.id === id ? { ...m, ...d, _hors_ligne: true } : m) : liste);
  },
});
const apiDeleteMaintenance  = (id)      => apiFetch(`/maintenance/${id}`, { method:'DELETE' });

// ── Logistique : Transport scolaire ──
const apiGetVehicules       = ()        => apiFetch('/transport/vehicules');
const apiCreateVehicule     = (d)       => apiFetch('/transport/vehicules', {
  method:'POST', body:d,
  descriptionHorsLigne: `Nouveau véhicule — ${d.immatriculation||''}`,
  donneesOptimistes: { ...d, statut: d.statut || 'actif' },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/transport/vehicules', (liste) => Array.isArray(liste) ? [{ ...d, id: idTemp, statut: d.statut || 'actif', _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateVehicule     = (id,d)    => apiFetch(`/transport/vehicules/${id}`, {
  method:'PUT', body:d,
  descriptionHorsLigne: `Modification d'un véhicule`,
  donneesOptimistes: { id, ...d },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/transport/vehicules', (liste) => Array.isArray(liste) ? liste.map(v => v.id === id ? { ...v, ...d, _hors_ligne: true } : v) : liste);
  },
});
const apiDeleteVehicule     = (id)      => apiFetch(`/transport/vehicules/${id}`, { method:'DELETE' });
const apiGetItineraires     = ()        => apiFetch('/transport/itineraires');
const apiCreateItineraire   = (d)       => apiFetch('/transport/itineraires', {
  method:'POST', body:d,
  descriptionHorsLigne: `Nouvel itinéraire — ${d.nom||''}`,
  donneesOptimistes: { ...d },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/transport/itineraires', (liste) => Array.isArray(liste) ? [{ ...d, id: idTemp, nb_eleves: 0, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateItineraire   = (id,d)    => apiFetch(`/transport/itineraires/${id}`, {
  method:'PUT', body:d,
  descriptionHorsLigne: `Modification d'un itinéraire`,
  donneesOptimistes: { id, ...d },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/transport/itineraires', (liste) => Array.isArray(liste) ? liste.map(i => i.id === id ? { ...i, ...d, _hors_ligne: true } : i) : liste);
  },
});
const apiDeleteItineraire   = (id)      => apiFetch(`/transport/itineraires/${id}`, { method:'DELETE' });
const apiGetTransportEleves = (q='')    => apiFetch('/transport/eleves'+(q?'?'+q:''));
const apiAssignTransportEleve = (d)     => apiFetch('/transport/eleves', {
  method:'POST', body:d,
  descriptionHorsLigne: `Affectation d'un élève au transport`,
  donneesOptimistes: { ...d },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/transport/eleves', (liste) => Array.isArray(liste) ? [{ ...d, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUnassignTransportEleve = (id)  => apiFetch(`/transport/eleves/${id}`, { method:'DELETE' });

const apiGetTransactionsRecurrentes = () => apiFetch('/transactions-recurrentes');
const apiCreateTransactionRecurrente = (d) => apiFetch('/transactions-recurrentes', { method:'POST', body:d });
const apiUpdateTransactionRecurrente = (id,d) => apiFetch(`/transactions-recurrentes/${id}`, { method:'PUT', body:d });
const apiDeleteTransactionRecurrente = (id) => apiFetch(`/transactions-recurrentes/${id}`, { method:'DELETE' });

const apiGetBudgets = (mois='') => apiFetch('/budgets'+(mois?'?mois='+mois:''));
const apiSaveBudget = (d) => apiFetch('/budgets', { method:'POST', body:d });
const apiDeleteBudget = (id) => apiFetch(`/budgets/${id}`, { method:'DELETE' });
const apiComparaisonBudget = (mois) => apiFetch('/budgets/comparaison?mois='+mois);
const apiAnalyseComptable = (mois) => apiFetch('/analyse-comptable?mois='+mois);
const apiGetBalance = (dateDebut, dateFin) => apiFetch(`/balance?date_debut=${dateDebut}&date_fin=${dateFin}`);
const apiGetReleve = (params) => apiFetch(`/releve?${new URLSearchParams(params).toString()}`);
const apiEnvoyerReleveEmail = (b) => apiFetch('/releve/envoyer-email', { method: 'POST', body: b });

function apiAnalyserRapprochement(fichier) {
  const fd = new FormData();
  fd.append('fichier', fichier);
  return apiUpload('/rapprochement/analyser', fd);
}
const apiValiderRapprochement = (id) => apiFetch(`/rapprochement/valider/${id}`, { method:'PUT' });
const apiAnnulerRapprochement = (id) => apiFetch(`/rapprochement/annuler/${id}`, { method:'PUT' });
const apiEtatRapprochement = (q='') => apiFetch('/rapprochement/etat'+(q?'?'+q:''));
function apiExportTransactionsExcel(q='') {
  const url = API_BASE + '/transactions/export' + (q?'?'+q:'');
  fetch(url, { headers: { 'Authorization': 'Bearer ' + _token } })
    .then(r => { if (!r.ok) return r.json().then(d => { throw new Error(d.error||'Erreur'); }); return r.blob(); })
    .then(blob => {
      const a = document.createElement('a');
      const objUrl = URL.createObjectURL(blob);
      a.href = objUrl; a.download = 'Journal-Comptable.xlsx';
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(objUrl);
    })
    .catch(err => toast(err.message, 'error'));
}
const apiCreateTransaction  = (b)       => apiFetch('/transactions', {
  method: 'POST', body: b,
  descriptionHorsLigne: `${b.type==='sortie'?'Décaissement':'Encaissement'} — ${b.description||b.categorie||''}`,
  donneesOptimistes: { ...b, statut_validation: 'auto' },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/transactions', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, statut_validation: 'auto', _hors_ligne: true }, ...liste] : liste);
  },
});
const apiDeleteTransaction  = (id)      => apiFetch(`/transactions/${id}`, { method: 'DELETE' });

/* ── Frais ── */
const apiGetFrais    = ()     => apiFetch('/frais');
const apiCreateFrais = (b)    => apiFetch('/frais', { method: 'POST', body: b });
const apiUpdateFrais = (id,b) => apiFetch(`/frais/${id}`, { method: 'PUT', body: b });
const apiDeleteFrais = (id)   => apiFetch(`/frais/${id}`, { method: 'DELETE' });

/* ── Paiements ── */
const apiGetPaiements  = (q='')  => apiFetch('/paiements'+(q?'?'+q:''));
const apiGenPaiements  = (b)     => apiFetch('/paiements/generer', { method: 'POST', body: b });
const apiCreatePaiement= (b)     => apiFetch('/paiements', { method: 'POST', body: b });
const apiDeletePaiement= (id, motif) => apiFetch(`/paiements/${id}`, { method: 'DELETE', body: { motif } });
const apiGetPaiementsSupprimes = () => apiFetch('/paiements-supprimes');
const apiGetImpayes = (qs = '') => apiFetch('/paiements-impayes' + (qs ? '?' + qs : ''));
const apiEnregistrerRelance = (eleveId, body) => apiFetch(`/paiements-impayes/${eleveId}/relance`, { method: 'POST', body });
const apiVerserPaiement= (id,b)  => apiFetch(`/paiements/${id}/verser`, {
  method: 'POST', body: b,
  descriptionHorsLigne: `Versement de ${b.montant||0} GNF`,
  donneesOptimistes: { id },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/paiements', (liste) => {
      if (!Array.isArray(liste)) return liste;
      return liste.map(p => p.id === id ? { ...p, montant_paye: (p.montant_paye||0) + (parseFloat(b.montant)||0), _hors_ligne: true } : p);
    });
  },
});
const apiSoldePaiements= (id)    => apiFetch(`/paiements/solde/${id}`);
const apiSoldesTous    = ()      => apiFetch('/paiements/soldes');
const apiVersementsEleve= (id)   => apiFetch(`/versements/${id}`);

/* ── Cantine ── */
const apiGetMenus    = (q='')    => apiFetch('/cantine/menus'+(q?'?'+q:''));
const apiCreateMenu  = (b)       => apiFetch('/cantine/menus', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouveau menu cantine`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/cantine/menus', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateMenu  = (id,b)    => apiFetch(`/cantine/menus/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification d'un menu cantine`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/cantine/menus', (liste) => Array.isArray(liste) ? liste.map(m => m.id === id ? { ...m, ...b, _hors_ligne: true } : m) : liste);
  },
});
const apiDeleteMenu  = (id)      => apiFetch(`/cantine/menus/${id}`, { method: 'DELETE' });
const apiGetAbons    = (q='')    => apiFetch('/cantine/abonnements'+(q?'?'+q:''));
const apiCreateAbon  = (b)       => apiFetch('/cantine/abonnements', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouvel abonnement cantine`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/cantine/abonnements', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateAbon  = (id,b)    => apiFetch(`/cantine/abonnements/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification d'un abonnement cantine`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/cantine/abonnements', (liste) => Array.isArray(liste) ? liste.map(a => a.id === id ? { ...a, ...b, _hors_ligne: true } : a) : liste);
  },
});
const apiPayerAbon   = (id,b)    => apiFetch(`/cantine/abonnements/${id}/payer`, {
  method: 'POST', body: b,
  descriptionHorsLigne: `Paiement d'un abonnement cantine`,
  donneesOptimistes: { id },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/cantine/abonnements', (liste) => {
      if (!Array.isArray(liste)) return liste;
      return liste.map(a => a.id === id ? { ...a, montant_paye: (a.montant_paye||0) + (parseFloat(b.montant)||0), _hors_ligne: true } : a);
    });
  },
});
const apiDeleteAbon  = (id)      => apiFetch(`/cantine/abonnements/${id}`, { method: 'DELETE' });

/* ── Communication ── */
const apiGetAnnonces    = ()     => apiFetch('/annonces');
const apiCreateAnnonce  = (b)    => apiFetch('/annonces', { method: 'POST', body: b });
const apiUpdateAnnonce  = (id,b) => apiFetch(`/annonces/${id}`, { method: 'PUT', body: b });
const apiDeleteAnnonce  = (id)   => apiFetch(`/annonces/${id}`, { method: 'DELETE' });
const apiGetMessages    = (q='') => apiFetch('/messages'+(q?'?'+q:''));
const apiCreateMessage  = (b)    => apiFetch('/messages', { method: 'POST', body: b });
const apiDeleteMessage  = (id)   => apiFetch(`/messages/${id}`, { method: 'DELETE' });

/* ── Dashboard ── */
const apiGetDashboard = () => apiFetch('/dashboard');

/* ── Classes ── */
const apiGetClassesFull = (q='') => apiFetch('/classes'+(q?'?'+q:''));
const apiCreateClasse   = (b)    => apiFetch('/classes', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouvelle classe — ${b.nom||''}`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/classes', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateClasse   = (id,b) => apiFetch(`/classes/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification de classe`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/classes', (liste) => Array.isArray(liste) ? liste.map(c => c.id === id ? { ...c, ...b, _hors_ligne: true } : c) : liste);
  },
});
const apiDeleteClasse   = (id)   => apiFetch(`/classes/${id}`, { method: 'DELETE' });

/* ── Approbation comptable ── */
const apiTransactionsEnAttente = () => apiFetch('/transactions/en-attente');
const apiApprouverTransaction  = (id)   => apiFetch(`/transactions/${id}/approuver`, { method: 'PUT' });
const apiRejeterTransaction    = (id,b) => apiFetch(`/transactions/${id}/rejeter`, { method: 'PUT', body: b });
const apiUpdateTransaction     = (id,b) => apiFetch(`/transactions/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification d'une transaction`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/transactions', (liste) => Array.isArray(liste) ? liste.map(t => t.id === id ? { ...t, ...b, _hors_ligne: true } : t) : liste);
  },
});
const apiUpdateSeuils          = (b)    => apiFetch('/settings/seuils-approbation', { method: 'PUT', body: b });

/* ── Journal d'audit ── */
const apiGetJournal  = (q='') => apiFetch('/journal'+(q?'?'+q:''));
const apiJournalMeta = ()     => apiFetch('/journal/entites');

/* ── Heures d'enseignement (personnel horaire) ── */
const apiGetHeuresPersonnel = (id)   => apiFetch(`/personnel/${id}/heures`);
const apiSaisirHeures       = (id,b) => apiFetch(`/personnel/${id}/heures`, { method: 'POST', body: b });

/* ── Séances de cours (traçabilité + validation direction) ── */
const apiGetSeancesCours     = (q='') => apiFetch('/seances-cours'+(q?'?'+q:''));
const apiCreateSeanceCours   = (b)    => apiFetch('/seances-cours', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouvelle séance de cours de révision`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/seances-cours', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiValiderSeanceCours  = (id)   => apiFetch(`/seances-cours/${id}/valider`, { method: 'PUT' });
const apiValiderGroupeSeances= (b)    => apiFetch('/seances-cours/valider-groupe', { method: 'PUT', body: b });
const apiRejeterSeanceCours  = (id,b) => apiFetch(`/seances-cours/${id}/rejeter`, { method: 'PUT', body: b });
const apiDeleteSeanceCours   = (id)   => apiFetch(`/seances-cours/${id}`, { method: 'DELETE' });
const apiCreneauxEmploiTemps = (pid)  => apiFetch(`/personnel/${pid}/creneaux-emploi-temps`);
const apiUploadPhotoPersonnel = (id,fd) => apiUpload(`/personnel/${id}/photo`, fd);

/* ── Articles / Actualités ── */
const apiGetArticles      = (q='') => apiFetch('/articles'+(q?'?'+q:''));
const apiGetArticlesAdmin = ()     => apiFetch('/articles/admin');
const apiGetArticle       = (id)   => apiFetch(`/articles/${id}`);
const apiCreateArticle    = (b)    => apiFetch('/articles', { method: 'POST', body: b });
const apiUpdateArticle    = (id,b) => apiFetch(`/articles/${id}`, { method: 'PUT', body: b });
const apiDeleteArticle    = (id)   => apiFetch(`/articles/${id}`, { method: 'DELETE' });
const apiUploadArticleMedia = (id,fd) => apiUpload(`/articles/${id}/media`, fd);
const apiDeleteArticleMedia = (id)    => apiFetch(`/articles/media/${id}`, { method: 'DELETE' });

/* ── Élève du mois ── */
const apiGetEleveDuMoisAll = () => apiFetch('/eleve-du-mois');
const apiGetEleveDuMoisActuel = () => apiFetch('/eleve-du-mois/actuel');
const apiDesignerEleveDuMois  = (b) => apiFetch('/eleve-du-mois', { method: 'POST', body: b });
const apiDeleteEleveDuMois    = (id) => apiFetch(`/eleve-du-mois/${id}`, { method: 'DELETE' });

/* ── Salles ── */
const apiGetSalles    = (q='') => apiFetch('/salles'+(q?'?'+q:''));
const apiCreateSalle  = (b)    => apiFetch('/salles', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouvelle salle — ${b.nom||''}`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/salles', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateSalle  = (id,b) => apiFetch(`/salles/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification de salle`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/salles', (liste) => Array.isArray(liste) ? liste.map(s => s.id === id ? { ...s, ...b, _hors_ligne: true } : s) : liste);
  },
});
const apiDeleteSalle  = (id)   => apiFetch(`/salles/${id}`, { method: 'DELETE' });

/* ── Paie / bulletins de salaire ── */
const apiCalculPaie      = (personnelId, mois) => apiFetch(`/paie/calcul/${personnelId}?mois=${mois}`);
const apiListePaie       = (mois) => apiFetch(`/paie/liste?mois=${mois}`);
const apiGenererBulletin = (b)    => apiFetch('/paie/bulletins', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Génération de bulletin de salaire`,
  donneesOptimistes: { en_attente_generation: true },
  // Volontairement PAS de mise à jour optimiste du cache ici : un bulletin de
  // salaire résulte d'un calcul serveur complexe (primes, avances en cours,
  // absences...) qu'on ne peut pas reproduire fidèlement côté client. Mieux
  // vaut ne rien afficher tant que la vraie génération n'a pas eu lieu, plutôt
  // que de risquer d'afficher un montant de salaire incorrect à un employé.
  // L'action reste bien mise en file et sera générée dès la reconnexion.
});
const apiGetBulletins    = (q='') => apiFetch('/paie/bulletins'+(q?'?'+q:''));
const apiGetBulletin     = (id)   => apiFetch(`/paie/bulletins/${id}`);
const apiDeleteBulletin  = (id)   => apiFetch(`/paie/bulletins/${id}`, { method: 'DELETE' });

/* ── Types de primes (liste déroulante modifiable) ── */
const apiGetTypesPrimes    = (q='') => apiFetch('/paie/types-primes'+(q?'?'+q:''));
const apiCreateTypePrime   = (b)    => apiFetch('/paie/types-primes', { method: 'POST', body: b });
const apiUpdateTypePrime   = (id,b) => apiFetch(`/paie/types-primes/${id}`, { method: 'PUT', body: b });
const apiDeleteTypePrime   = (id)   => apiFetch(`/paie/types-primes/${id}`, { method: 'DELETE' });

/* ── Avances sur salaire (plafond 40%) ── */
const apiGetAvances        = (q='') => apiFetch('/paie/avances'+(q?'?'+q:''));
const apiPlafondAvance     = (personnelId) => apiFetch(`/paie/avances/plafond/${personnelId}`);
const apiCreateAvance      = (b)    => apiFetch('/paie/avances', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Avance sur salaire — ${b.montant||0} GNF`,
  donneesOptimistes: { ...b, statut: 'en_cours' },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    // Remarque : le serveur applique un plafond (calculé à partir du salaire de
    // référence et des avances déjà en cours) que l'on ne peut pas vérifier de
    // façon fiable hors ligne. Si le plafond est dépassé, la synchronisation
    // rejettera proprement l'avance et préviendra l'utilisateur — elle n'est
    // jamais validée silencieusement à tort.
    await offlinePatcherVariantes('/paie/avances', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, statut: 'en_cours', _hors_ligne: true }, ...liste] : liste);
  },
});
const apiAnnulerAvance     = (id)   => apiFetch(`/paie/avances/${id}/annuler`, { method: 'PUT' });

/* ── Validation de la masse salariale (comptable → directeur → admin) ── */
const apiGetValidationPaie   = (mois) => apiFetch(`/paie/validation?mois=${mois}`);
const apiSoumettreValidation = (b)    => apiFetch('/paie/validation', { method: 'POST', body: b });
const apiValiderDirecteur    = (id,b={}) => apiFetch(`/paie/validation/${id}/valider-directeur`, { method: 'PUT', body: b });
const apiValiderAdminPaie    = (id,b={}) => apiFetch(`/paie/validation/${id}/valider-admin`, { method: 'PUT', body: b });

/* ── Candidatures enseignants ── */
const apiSoumettreCandidature = (b) => apiFetch('/candidatures', { method: 'POST', body: b });
const apiGetCandidatures  = (q='') => apiFetch('/candidatures'+(q?'?'+q:''));
const apiGetCandidature   = (id)   => apiFetch(`/candidatures/${id}`);
const apiApprouverCandidature = (id) => apiFetch(`/candidatures/${id}/approuver`, { method: 'PUT' });
const apiRejeterCandidature   = (id,b) => apiFetch(`/candidatures/${id}/rejeter`, { method: 'PUT', body: b });
const apiDeleteCandidature = (id) => apiFetch(`/candidatures/${id}`, { method: 'DELETE' });

/* ── Enseignants / séances des cours de révision ── */
const apiGetEnseignantsCours = (coursId) => apiFetch(`/cours-revision/${coursId}/enseignants`);
const apiAssignerEnseignant  = (coursId,b) => apiFetch(`/cours-revision/${coursId}/enseignants`, { method: 'POST', body: b });
const apiRetirerEnseignant   = (ceId) => apiFetch(`/cours-revision/enseignants/${ceId}`, { method: 'DELETE' });
const apiGetSeances          = (coursId) => apiFetch(`/cours-revision/${coursId}/seances`);
const apiEnregistrerSeance   = (coursId,b) => apiFetch(`/cours-revision/${coursId}/seances`, { method: 'POST', body: b });
const apiDeleteSeance        = (sId) => apiFetch(`/cours-revision/seances/${sId}`, { method: 'DELETE' });
const apiCalculRedistribution = (mois) => apiFetch(`/cours-revision/redistribution?mois=${mois}`);
const apiVerserRedistribution = (b) => apiFetch('/cours-revision/redistribution/verser', { method: 'POST', body: b });

/* ── Cours de révision (payants, ouverts aux externes, avec évaluation) ── */
const apiGetCoursRevision      = (q='') => apiFetch('/cours-revision'+(q?'?'+q:''));
const apiGetCoursRevisionOne   = (id)   => apiFetch(`/cours-revision/${id}`);
const apiCreateCoursRevision   = (b)    => apiFetch('/cours-revision', {
  method: 'POST', body: b,
  descriptionHorsLigne: `Nouveau cours de révision — ${b.matiere||''}`,
  donneesOptimistes: { ...b },
  miseAJourCacheHorsLigne: async ({ idTemp }) => {
    await offlinePatcherVariantes('/cours-revision', (liste) => Array.isArray(liste) ? [{ ...b, id: idTemp, _hors_ligne: true }, ...liste] : liste);
  },
});
const apiUpdateCoursRevision   = (id,b) => apiFetch(`/cours-revision/${id}`, {
  method: 'PUT', body: b,
  descriptionHorsLigne: `Modification d'un cours de révision`,
  donneesOptimistes: { id, ...b },
  miseAJourCacheHorsLigne: async () => {
    await offlinePatcherVariantes('/cours-revision', (liste) => Array.isArray(liste) ? liste.map(c => c.id === id ? { ...c, ...b, _hors_ligne: true } : c) : liste);
  },
});
const apiDeleteCoursRevision   = (id)   => apiFetch(`/cours-revision/${id}`, { method: 'DELETE' });
const apiGetRevisionParticipants = (coursId) => apiFetch(`/cours-revision/${coursId}/participants`);
const apiAddRevisionParticipant  = (coursId,b) => apiFetch(`/cours-revision/${coursId}/participants`, { method: 'POST', body: b });
const apiDeleteRevisionParticipant = (pId) => apiFetch(`/cours-revision/participants/${pId}`, { method: 'DELETE' });
const apiPayerRevisionParticipant  = (pId,b) => apiFetch(`/cours-revision/participants/${pId}/payer`, { method: 'POST', body: b });
const apiGetRevisionEvaluations = (pId) => apiFetch(`/cours-revision/participants/${pId}/evaluations`);
const apiCreateRevisionEvaluation = (pId,b) => apiFetch(`/cours-revision/participants/${pId}/evaluations`, { method: 'POST', body: b });
const apiDeleteRevisionEvaluation = (eId) => apiFetch(`/cours-revision/evaluations/${eId}`, { method: 'DELETE' });

/* ── Résultats scolaires (coefficients, bulletins, fin d'année) ── */
const apiGetMatieresClasse   = (classe) => apiFetch('/matieres-classe?classe=' + encodeURIComponent(classe));
const apiSetMatieresClasse   = (classe, matieres) => apiFetch('/matieres-classe', { method:'PUT', body:{ classe, matieres } });
const _qAnnee = (a) => a ? '&annee_scolaire=' + encodeURIComponent(a) : '';
const apiGetBulletinsClasse  = (classe, periode, annee) => apiFetch('/bulletins/classe/' + encodeURIComponent(classe) + '?periode=' + periode + _qAnnee(annee));
const apiGetAnnees           = () => apiFetch('/bulletins/annees');
const apiGetParcours         = (id) => apiFetch('/eleves/' + encodeURIComponent(id) + '/parcours');
const apiGetBulletinEleve    = (id, periode, annee) => apiFetch('/bulletins/eleve/' + encodeURIComponent(id) + '?periode=' + periode + _qAnnee(annee));
const apiSetAppreciation     = (eleve_id, periode, appreciation) => apiFetch('/bulletins/appreciation', { method:'PUT', body:{ eleve_id, periode, appreciation } });
const apiGetFinAnnee         = (classe, annee) => apiFetch('/fin-annee/' + encodeURIComponent(classe) + (annee ? '?annee_scolaire=' + encodeURIComponent(annee) : ''));
const apiSaveDecisions       = (annee_scolaire, classe, decisions) => apiFetch('/fin-annee/decisions', { method:'POST', body:{ annee_scolaire, classe, decisions } });
const apiProposerReinscriptions = (annee_scolaire, nouvelle_annee) => apiFetch('/fin-annee/reinscriptions', { method:'POST', body:{ annee_scolaire, nouvelle_annee } });

/* ── Import d'élèves et attestations ── */
const apiImporterEleves = (fichier, simulation) => { const fd = new FormData(); fd.append('fichier', fichier); if (simulation) fd.append('simulation', '1'); return apiUpload('/import-eleves', fd); };
const apiDelivrerAttestation = (id) => apiFetch(`/eleves/${encodeURIComponent(id)}/attestation`, { method: 'POST' });
